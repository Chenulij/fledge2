console.log("Employer dashboard script loaded!");
