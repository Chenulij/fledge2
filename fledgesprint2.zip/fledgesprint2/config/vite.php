<?php

return [
    'build_path' => public_path('build'),
];
