<!-- resources/views/employer/dashboard.blade.php -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employer Dashboard - Fledge</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/jobs.js'); ?>
    <script src="https://cdn.tailwindcss.com"></script>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>

<body class="bg-gray-100">
    <?php echo $__env->make('components.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="container mx-auto px-4 py-10">
        <h2 class="text-2xl font-bold text-purple-900 mb-6">My Posted Jobs</h2>

        <?php if(session('success')): ?>
            <div class="bg-green-100 text-green-800 px-4 py-2 rounded mb-4">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php $__empty_1 = true; $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="p-4 bg-white shadow rounded mb-4">
                <h3 class="text-xl font-bold"><?php echo e($job->title); ?></h3>
                <p class="text-sm text-gray-600 mt-1"><?php echo e($job->category); ?> | <?php echo e($job->job_type); ?> | <?php echo e($job->location); ?></p>
                <p class="text-sm text-gray-600 mt-1">Pay Rate: <?php echo e($job->pay_rate); ?></p>
                <p class="mt-3 text-gray-800"><?php echo e($job->description); ?></p>

                <!-- Applications Section -->
                <div class="mt-4">
                    <h4 class="font-bold text-lg">Applications</h4>

                    <?php $__empty_2 = true; $__currentLoopData = $job->applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                        <div class="mt-3 p-4 bg-gray-50 border rounded-md">
                            <p class="font-semibold"><?php echo e($application->student->name); ?></p>
                            <p class="text-sm text-gray-600">Applied on: <?php echo e($application->created_at->toFormattedDateString()); ?></p>
                            <a href="<?php echo e(route('employer.job.edit', $job->id)); ?>" class="text-blue-600 hover:underline mt-2 inline-block">View Application</a>
                            <!-- Add logic to mark job as "completed" -->
                            <form action="<?php echo e(route('employer.job.complete', $job->id)); ?>" method="POST" class="inline-block ml-2">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <button type="submit" class="text-green-600 hover:underline">Mark as Completed</button>
                            </form>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                        <p>No applications yet.</p>
                    <?php endif; ?>
                </div>

                <!-- Edit/Delete Job Options -->
                <div class="mt-4 flex space-x-4">
                    <a href="<?php echo e(route('employer.job.edit', $job->id)); ?>" class="text-blue-600 hover:underline">Edit</a>

                    <form action="<?php echo e(route('employer.job.delete', $job->id)); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete this job?');">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="text-red-600 hover:underline">Delete</button>
                    </form>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="text-gray-700">No jobs posted yet. <a href="<?php echo e(route('employer.job.create')); ?>" class="text-purple-600 hover:underline">Post a job</a></p>
        <?php endif; ?>
    </div>

    <?php echo $__env->make('components.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>

</html>
<?php /**PATH C:\Users\ameli\Desktop\fledge sprint 2\resources\views/employer/dashboard.blade.php ENDPATH**/ ?>